import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;

class SearchEngine {
    public void listOutputer(String searchQueryListOutputer) {
        filePathsReader();
        List<String> results = new ArrayList<>();
        ListMethods listMethods = new ListMethods();
        results = listMethods.searchResults(searchQueryListOutputer);
        for (int i = 0; i < results.size(); i++) {
            System.out.println("\n" + ShellCommands.colorCodesData[5] +  results.get(i) + "\n\033[0m");
        }
        
    }

    public List<String> filePathsReader () {
        Path pathToFilePaths = Path.of("/Users/graham/Desktop/Java/src/filePaths.txt");
        try {
            List<String> lines = Files.readAllLines(pathToFilePaths);
            return lines;
        } catch (IOException e) {
            System.err.println("⚠️Could not find the file! Make sure 'filePaths.txt' is in your main project folder.");
        }
        List<String> yep =  new ArrayList<>();
        return yep;
    }

    public List<String> fileNames = new ArrayList<>();
}

class ListMethods extends SearchEngine{
    public List<String> listOfResults = new ArrayList<>();
    public  List<String> searchResults(String searchResultsString) {
        boolean topResults[] = searchEngine(searchResultsString);
        for (int i = 0; i < topResults.length; i++) {
            if (topResults[i] == true) {
                listOfResults.add(fileNames.get(i));
            }
        }
        return listOfResults;
    }

    private boolean[] searchEngine (String searchEngineString) {
        int matchingLetters[] = {0, 0, 0, 0, 0};
        double matchPercentages[] = {0.0, 0.0, 0.0, 0.0, 0.0};
        boolean topTenResults[] = {false, false, false, false, false};
        String character_j = "";
        for (int i = 0; i < fileNames.size(); i++) {
            for (int j = 0; j < fileNames.get(i).length(); j++) {
                character_j = fileNames.get(i).substring(j, j + 1); // What is this doing?
                for (int k = 0; k < searchEngineString.length(); k++) {
                    if (searchEngineString.substring(k, k + 1).equals(character_j)) {
                        matchingLetters[i]++;
                    }
                }
            }
        }
        for (int i = 0; i < matchPercentages.length; i++) {
            matchPercentages[i] = (((double) matchingLetters[i]) / searchEngineString.length()) * 100.0;
        }
        for (int i = 0; i < matchPercentages.length; i++) {
            System.out.println("\t");
            // 0
            if (matchPercentages[i] != 0.0) {
                if (i == 0) {
                    if ((matchPercentages[matchPercentages.length - 1] < matchPercentages[0]) && 
                    (matchPercentages[0] > matchPercentages[matchPercentages.length - 2])) {
                        topTenResults[i] = true;
                        System.out.println(i + "Search result has a " + matchPercentages[i] + "% match");
                    }
                }
                // 1
                if (i == matchPercentages.length - 1) {
                    if ((matchPercentages[matchPercentages.length - 1] > matchPercentages[0]) && 
                    (matchPercentages[matchPercentages.length - 1] > matchPercentages[matchPercentages.length - 2])) {
                        topTenResults[i] = true;
                        System.out.println(i + "Search result has a " + matchPercentages[i] + "% match");
                    }
                }
                // 2
                if ((i != 0) && (i != matchPercentages.length - 1)) {
                    if ((matchPercentages[i] > matchPercentages[i - 1]) && (matchPercentages[i] > matchPercentages[i + 1])) {
                        topTenResults[i] = true;
                        System.out.println(i + "Search result has a " + matchPercentages[i] + "% match");
                    }
                }
            }
        }
        return topTenResults;
    };
}